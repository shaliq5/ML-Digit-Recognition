import flask
from flask import Flask, request, render_template
from sklearn.externals import joblib
import numpy as np
import cv2
from scipy import misc
import matplotlib.pyplot as plt
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.utils import np_utils
import cv2
import os
VIZ_FOLDER = os.path.join('static', 'viz')


app = Flask(__name__)
app.config['VIZ_FOLDER'] = VIZ_FOLDER
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0


@app.route("/")
@app.route("/index")
def index():
    return flask.render_template('index.html')

def Convert_one_to_label(a):
    max = 0
    for i in range(0,len(a)):
        if(a[i]>max):
            label = i;
            max = a[i]
    return label

def make_predictions(example):
    #example = np.dot(example[...,:3], [0.299, 0.587, 0.114])
    example = example.reshape(1,1,28,28)
    #print(example)
    pred = model.predict(example)
    #print(pred)
    #plt.imshow(pred, cmap=plt.get_cmap('gray'))
    #return True
    return Convert_one_to_label(pred[0])

# here we get rid of that added dimension and plot the image
def visualize_data1(model, data):
    # Keras expects batches of images, so we have to add a dimension to trick it into being nice
    data_batch = np.expand_dims(data,axis=0)
    conv_data = model.predict(data_batch)
    conv_data = np.squeeze(conv_data, axis=0)
    print(conv_data.shape)
    plt.subplot(221)
    plt.imshow(conv_data)
    plt.savefig('static/viz/one.png', dpi=300, bbox_inches='tight')
    return True

def visualize_data2(model, data):
    # Keras expects batches of images, so we have to add a dimension to trick it into being nice
    data_batch = np.expand_dims(data,axis=0)
    conv_data = model.predict(data_batch)
    conv_data = np.squeeze(conv_data, axis=0)
    print(conv_data.shape)
    plt.subplot(221)
    plt.imshow(conv_data)
    plt.savefig('static/viz/two.png', dpi=300, bbox_inches='tight')
    return True

def visualize_data3(model, data):
    # Keras expects batches of images, so we have to add a dimension to trick it into being nice
    data_batch = np.expand_dims(data,axis=0)
    conv_data = model.predict(data_batch)
    conv_data = np.squeeze(conv_data, axis=0)
    #print(conv_data.shape)
    plt.subplot(221)
    plt.imshow(conv_data)
    plt.savefig('static/viz/three.png', dpi=300, bbox_inches='tight')
    return True

def visualize_data4(model, data):
    # Keras expects batches of images, so we have to add a dimension to trick it into being nice
    data_batch = np.expand_dims(data,axis=0)
    conv_data = model.predict(data_batch)
    conv_data = np.squeeze(conv_data, axis=0)
    #print(conv_data.shape)
    plt.subplot(221)
    plt.imshow(conv_data)
    plt.savefig('static/viz/four.png', dpi=300, bbox_inches='tight')
    return True

def visualize_data5(model, data):
    # Keras expects batches of images, so we have to add a dimension to trick it into being nice
    data_batch = np.expand_dims(data,axis=0)
    conv_data = model.predict(data_batch)
    conv_data = np.squeeze(conv_data, axis=0)
    #print(conv_data.shape)
    plt.subplot(221)
    plt.imshow(conv_data)
    plt.savefig('static/viz/five.png', dpi=300, bbox_inches='tight')
    return True

# here we get rid of that added dimension and plot the image
def visualize_data6(model, data):
    # Keras expects batches of images, so we have to add a dimension to trick it into being nice
    data_batch = np.expand_dims(data,axis=0)
    conv_data = model.predict(data_batch)
    print(conv_data.shape)
    plt.imshow(conv_data, cmap=plt.get_cmap('gray'))
    plt.savefig('static/viz/six.png', dpi=300, bbox_inches='tight')
    return True

def visualize_digit(example):
    example = example.reshape(1,1,28,28)
    pred = model.predict(example)
    plt.imshow(pred, cmap=plt.get_cmap('gray'))
    plt.savefig('static/viz/vis.png', dpi=300, bbox_inches='tight')

@app.route('/predict', methods=['POST'])
def make_prediction():
    if request.method == 'POST':

        file = request.files['image']
        if not file: return render_template('index.html', label="No file")
        imgcv = misc.imread(file)
        #plt.imshow(imgcv, cmap=plt.get_cmap('gray'))
        #print(imgcv.shape)
        #imgcv = cv2.imread('img_5.jpg')
        #print(imgcv)
        label = make_predictions(imgcv)
        #label=1;

        return render_template('index.html', label=label)



def convert(example):
    example = example.reshape(1,784)
    pred = noise.predict(example)
    pred = pred.reshape(28,28)
    plt.figure(figsize=(3, 3))
    plt.imshow(pred)
    plt.title('Reconstructed image')
    if plt.savefig('static/viz/recon.png', dpi=300, bbox_inches='tight'):
        print("Success")
    else:
        print("Save image failed recon")

@app.route('/noice', methods=['POST'])
def remove_noice():
    file = request.files['image3']
    if not file: return render_template('index.html', label="No file")
    imgcv = misc.imread(file)
    original=imgcv
    noise_factor = 80.8
    imgcv = imgcv + noise_factor * np.random.normal(size=imgcv.shape)
    plt.imshow(imgcv)
    if plt.savefig('static/viz/nosy.png', dpi=300, bbox_inches='tight'):
        print("Success")
    else:
        print("Save image failed")

    convert(imgcv)

    label3 = make_predictions(original)

    nosy_filename = os.path.join(app.config['VIZ_FOLDER'], 'nosy.png')
    recon_filename = os.path.join(app.config['VIZ_FOLDER'], 'recon.png')

    return render_template('index.html', label3=label3, image_nosy = nosy_filename, image_recon = recon_filename)

@app.route('/visualize', methods=['GET','POST'])
def visualize():
    if request.method == 'POST':

        file = request.files['image2']

        if not file: return render_template('index.html', label="No file")
        imgcv = misc.imread(file)
        # imgcv = np.dot(imgcv[..., :3], [0.299, 0.587, 0.114])
        # imgcv = imgcv.reshape(1, 1, 28, 28)
        #
        # label=make_predictions(imgcv)
        #plt.imshow(imgcv, cmap=plt.get_cmap('gray'))
        #print(imgcv.shape)
        #imgcv = cv2.imread('img_5.jpg')
        #print(imgcv)

        #*****layer 1*******
        # create model with only 1 conv layer
        data1 = imgcv
        data1 = np.stack((data1,) * 3, axis=-1)
        #imgCV.shape
        model1 = Sequential()
        # Applying first Convolution opertation
        model1.add(Conv2D(3, (3, 3), input_shape=data1.shape, activation='relu'))
        visualize_data1(model1, data1)

        #*******layer2*****
        # define the model with conv1 and max_pooling
        # create model
        data2 = imgcv
        data2 = np.stack((data2,) * 3, axis=-1)
        model2 = Sequential()
        # Applying first Convolution opertation
        model2.add(Conv2D(3, (3, 3), input_shape=data2.shape, activation='relu'))
        model2.add(MaxPooling2D(pool_size=(2, 2)))
        flag2 = visualize_data2(model2, data2)

        #*******layer3*******
        # define the model3 with 2conv operations and 1 max pooling operation
        # create model
        data3 = imgcv
        data3 = np.stack((data3,) * 3, axis=-1)
        model3 = Sequential()

        # Applying first Convolution opertation
        model3.add(Conv2D(3, (3, 3), input_shape=data3.shape, activation='relu'))
        model3.add(MaxPooling2D(pool_size=(2, 2)))

        # Applying Second Convolution opertation
        model3.add(Conv2D(3, (3, 3), activation='relu'))
        flag3= visualize_data3(model3, data3)

        #***********layer4**********
        # define the model3 with 2conv operations and 1 max pooling operation
        # create model
        data4 = imgcv
        data4=data3 = np.stack((data4,) * 3, axis=-1)
        model4 = Sequential()
        # Applying first Convolution opertation
        model4.add(Conv2D(3, (3, 3), input_shape=data3.shape, activation='relu'))
        model4.add(MaxPooling2D(pool_size=(2, 2)))
        # Applying Second Convolution opertation
        model4.add(Conv2D(3, (3, 3), activation='relu'))
        model4.add(MaxPooling2D(pool_size=(2, 2)))
        flag4 = visualize_data4(model4, data4)

        #***********layer5**********
        # define the model3 with 2conv operations and 1 max pooling operation

        # create model
        data5 = imgcv
        data5 = np.stack((data5,) * 3, axis=-1)
        model5 = Sequential()

        # Applying first Convolution opertation
        model5.add(Conv2D(3, (3, 3), input_shape=data5.shape, activation='relu'))
        model5.add(MaxPooling2D(pool_size=(2, 2)))

        # Applying Second Convolution opertation
        model5.add(Conv2D(3, (3, 3), activation='relu'))
        model5.add(MaxPooling2D(pool_size=(2, 2)))
        # dropout
        model5.add(Dropout(0.2))
        flag5 = visualize_data5(model5, data5)

        #***********layer6**********
        # define the model3 with 2conv operations and 1 max pooling operation

        # create model
        data6 = imgcv
        data6 = np.stack((data6,) * 3, axis=-1)
        model6 = Sequential()

        # Applying first Convolution opertation
        model6.add(Conv2D(3, (3, 3), input_shape=data6.shape, activation='relu'))
        model6.add(MaxPooling2D(pool_size=(2, 2)))

        # Applying Second Convolution opertation
        model6.add(Conv2D(3, (3, 3), activation='relu'))
        model6.add(MaxPooling2D(pool_size=(2, 2)))
        # dropout
        model6.add(Dropout(0.2))
        # flattening
        model6.add(Flatten())
        flag6 = visualize_data6(model6, data6)


        label = make_predictions(imgcv)
        visualize_digit(imgcv)
        #label=1;
        c=0;
        while not flag6:
            c+=1

        #print(c)
        full_filename1 = os.path.join(app.config['VIZ_FOLDER'], 'one.png')
        full_filename2 = os.path.join(app.config['VIZ_FOLDER'], 'two.png')
        full_filename3 = os.path.join(app.config['VIZ_FOLDER'], 'three.png')
        full_filename4 = os.path.join(app.config['VIZ_FOLDER'], 'four.png')
        full_filename5 = os.path.join(app.config['VIZ_FOLDER'], 'five.png')
        full_filename6 = os.path.join(app.config['VIZ_FOLDER'], 'six.png')
        full_filename7 = os.path.join(app.config['VIZ_FOLDER'], 'vis.png')
        return render_template('index.html', label=label, image_one = full_filename1, image_two = full_filename2,
                               image_three = full_filename3, image_four = full_filename4,  image_five = full_filename5,
                               image_six = full_filename6, image_seven = full_filename7)

# No cacheing at all for API endpoints.
@app.after_request
def add_header(response):
    # response.cache_control.no_store = True
    if 'Cache-Control' not in response.headers:
        response.headers['Cache-Control'] = 'no-store'
    return response

if __name__ == '__main__':
    # load ml model
    model = joblib.load('model.pkl')
    noise = joblib.load('noise.pkl')
    # start api
    #app.run(host='0.0.0.0', port=8000, debug=True)

    app.run(port=8000, debug=True, use_reloader=True)

